<?php get_header(); ?>
<?php include('templates/page.php'); ?>
<?php get_footer(); ?>
