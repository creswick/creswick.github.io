	</div>
	<!-- main END -->

	<?php get_sidebar(); ?>
	<div class="fixed"></div>
</div>
<!-- content END -->

<?php include('templates/end.php'); ?>
