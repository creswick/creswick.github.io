<?php include('templates/start.php'); ?>

<!-- container START -->
<div id="container">

<?php include('templates/header.php'); ?>

<!-- content START -->
<div id="content">

	<!-- main START -->
	<div id="main">
